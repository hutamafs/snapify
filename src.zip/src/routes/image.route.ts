import { Router } from "express";
import * as imageController from "../controller/image.controller";
import { middleware } from "../middleware/auth.middleware";

const imageRouter = Router();

imageRouter.get("/me", middleware, imageController.getMyImages);
imageRouter.post("/:id/like", middleware, imageController.likeImage);
imageRouter.delete("/:id/like", middleware, imageController.unlikeImage);
imageRouter.post("/:id/comment", middleware, imageController.postComment);
imageRouter.post("/upload", middleware, imageController.postImage);
imageRouter.get("/", imageController.getAllImages);

export default imageRouter;
