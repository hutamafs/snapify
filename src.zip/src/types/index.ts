import { registerSchema, loginSchema } from "./auth.schema";
import { postImageSchema, postCommentSchema } from "./image.schema";

export { registerSchema, loginSchema, postImageSchema, postCommentSchema };
