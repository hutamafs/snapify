import { commentsTable, imagesTable, likesTable } from "../db/schema";
import { eq, desc, count, and } from "drizzle-orm";
import db from "../db";

const getAllImages = async () => {
  const images = await db.select().from(imagesTable);
  return images;
};

const getMyImages = async (userId: number, limit: number, offset: number) => {
  const images = await db
    .select()
    .from(imagesTable)
    .where(eq(imagesTable.userId, userId))
    .orderBy(desc(imagesTable.createdAt))
    .limit(limit)
    .offset(offset);

  const [total] = await db
    .select({ count: count() })
    .from(imagesTable)
    .where(eq(imagesTable.userId, userId));
  return { images, total: total.count };
};

const postImage = async (
  {
    s3Key,
    url,
    metadata,
  }: {
    s3Key: string;
    url: string;
    metadata?: string[];
  },
  userId: number,
) => {
  const [image] = await db.insert(imagesTable).values({ s3Key, url, userId, metadata }).returning();
  return image;
};

const likeImage = async (imageId: string, userId: number) => {
  const [image] = await db.select().from(imagesTable).where(eq(imagesTable.id, +imageId));
  if (!image) throw new Error("image does not exist");
  if (image.userId !== userId) {
    throw new Error("you do not own this image");
  }
  const like = await db.insert(likesTable).values({ imageId: +imageId, userId });
  return like;
};

const unlikeImage = async (imageId: string, userId: number) => {
  const [image] = await db
    .select()
    .from(likesTable)
    .where(and(eq(likesTable.imageId, +imageId), eq(likesTable.userId, userId)));
  if (!image) throw new Error("like does not exist");
  await db
    .delete(likesTable)
    .where(and(eq(likesTable.imageId, +imageId), eq(likesTable.userId, userId)));
};

const postComment = async ({ content }: { content: string }, imageId: string, userId: number) => {
  const [image] = await db.select().from(imagesTable).where(eq(imagesTable.id, +imageId));
  if (!image) throw new Error("image does not exist");
  if (image.userId !== userId) {
    throw new Error("you do not own this image");
  }
  const comment = await db.insert(commentsTable).values({ imageId: +imageId, userId, content });
  return comment;
};

export { getAllImages, getMyImages, postImage, likeImage, unlikeImage, postComment };
